
import random 

print('')
print('Begin SCOAP & Monte Carlos Simulation: ')

while (True):
  circuit_inputs = []
  circuit_outputs = []
  circuit_gate = []
  circuit_line = []

  node_type = {}
  node_levels = {}
  node_prerequiste = {}
  node_dependents = {}
  node_control = {}
  
  print('')
  print('(press q = QUIT)')
  print('')
  user_input = input('Enter file name: ')
  
  if(user_input == 'q'):
    break

  file = open(user_input, 'r')
  lines = file.readlines()

  def evaluate_circuit(inputs, circuit_gates, node_prerequiste):
      node_values = {}

      for node, value in inputs.items():
          node_values[node] = value

      unevaluated_gates = circuit_gates.copy()

      while unevaluated_gates:
          remaining_gates = []

          for gate in unevaluated_gates:
              output_node, gate_expression = gate.split("=", 1)
              output_node = output_node.strip()
              #print(output_node)
              
              gate_type, input_nodes = gate_expression.split("[", 1)
              gate_type = gate_type.strip()
              #print(gate_type)
              
              input_nodes = node_prerequiste[output_node]
              #print(input_nodes)
              
              if all(node in node_values for node in input_nodes):
                  
                  if gate_type == 'AND':
                      result = 1
                      for node in input_nodes:
                          result &= node_values[node]
                  elif gate_type == 'NAND':
                      result = 1
                      for node in input_nodes:
                          result &= node_values[node]
                      result = 1 - result
                  elif gate_type == 'OR':
                      result = 0
                      for node in input_nodes:
                          result |= node_values[node]
                  elif gate_type == 'NOR':
                      result = 0
                      for node in input_nodes:
                          result |= node_values[node]
                      result = 1 - result
                  elif gate_type == 'XOR':
                      result = 0
                      for node in input_nodes:
                          result ^= node_values[node]
                  elif gate_type == 'NOT':
                      input_node = input_nodes[0]
                      result = 1 - node_values[input_node]
                  elif gate_type == 'BUFF':
                      #print(input_nodes[0])
                      input_node = input_nodes[0]
                      result = node_values[input_node]

                  node_values[output_node] = result
              else:
                  remaining_gates.append(gate)

          if len(remaining_gates) == len(unevaluated_gates):
              print("Unable to evaluate all gates due to unresolved dependencies.")
              break

          unevaluated_gates = remaining_gates

      return node_values

  for formatted_line in lines:
      
      location_input = -1
      location_output = -1
      location_and = -1
      location_nand = -1
      location_or = -1
      location_nor = -1
      location_xor = -1
      location_buff = -1
      location_not = -1
      location_equal = -1
      location_finder = -1
      
      formatted_line = formatted_line.strip()
      
      if (not (formatted_line.startswith("#"))):
    
          formatted_line = formatted_line.strip()
      
          # I/O
          location_input = formatted_line.find('INPUT')
          location_output = formatted_line.find('OUTPUT')
      
          # AND
          location_and = formatted_line.find('AND')
          location_nand = formatted_line.find('NAND')
      
          # OR
          location_or = formatted_line.find('OR')
          location_nor = formatted_line.find('NOR')
          location_xor = formatted_line.find('XOR')
      
          # Other
          location_buff = formatted_line.find('BUFF')
          location_not = formatted_line.find('NOT')
      
          location_equal = formatted_line.find('=')
          location_finder = formatted_line.find(')')
        
        ####################################################################
    
      if location_input != -1:
          
          node = formatted_line[location_input + 6:-1].strip()
          circuit_inputs.append(node)
    
          node_levels[node] = 0
    
          if node not in node_prerequiste:
    
            node_prerequiste[node] = []
            node_dependents[node] = []
    
      ####################################################################
    
      if location_output != -1:
    
          node = formatted_line[location_output + 7:-1].strip()
          circuit_outputs.append(node)
    
          if node not in node_prerequiste:
            node_prerequiste[node] = []
            node_dependents[node] = []
            
      ####################################################################
      
      # AND GATE FORMATTING
      if location_and != -1 and location_nand == -1:
    
          gate_output = formatted_line[:location_equal].strip()
          gate_output = gate_output.strip('=')
          inputs = formatted_line[location_and + 4:-1].split(',')
          circuit_gate.append(gate_output)
          #print(inputs)
          node_type[gate_output] = 'AND'
          
          inputs_clean = []
          for input_node in inputs:
            cleaned = input_node.strip()
            #print(cleaned)
            inputs_clean.append(cleaned)
    
          circuit_line.append(
            f'{gate_output} = AND{inputs_clean}'
          )
          #print(f'{gate_output} = AND{inputs_clean}')
          #print('XXXXXXXXXXX')

          
          if gate_output not in node_prerequiste:
            node_prerequiste[gate_output] = []
            node_dependents[gate_output] = []
    
          for node in inputs_clean:
    
            if node not in node_prerequiste[gate_output]:
              node_prerequiste[gate_output].append(node)
    
            if node not in node_prerequiste:
              node_prerequiste[node] = []
              node_dependents[node] = []
    
            if gate_output not in node_dependents[node]:
              node_dependents[node].append(gate_output)
    
        ####################################################################
      
      
        # NAND GATE FORMATTING
      if location_nand != -1:
    
          gate_output = formatted_line[:location_equal].strip()
          gate_output = gate_output.strip('=')
          inputs = formatted_line[location_nand + 5:-1].split(',')
          circuit_gate.append(gate_output)
          node_type[gate_output] = 'NAND'
          
          inputs_clean = []
          for input_node in inputs:
            cleaned = input_node.strip()
            inputs_clean.append(cleaned)
    
          circuit_line.append(
            f'{gate_output} = NAND{inputs_clean}'
          )
    
          if gate_output not in node_prerequiste:
            node_prerequiste[gate_output] = []
            node_dependents[gate_output] = []
    
          for node in inputs_clean:
    
            if node not in node_prerequiste[gate_output]:
              node_prerequiste[gate_output].append(node)
    
            if node not in node_prerequiste:
              node_prerequiste[node] = []
              node_dependents[node] = []
    
            if gate_output not in node_dependents[node]:
              node_dependents[node].append(gate_output)
    
      ####################################################################
    
      # OR GATE FORMATTING
      if location_or != -1 and location_nor == -1 and location_xor == -1:
    
          gate_output = formatted_line[:location_equal].strip()
          gate_output = gate_output.strip('=')
          inputs = formatted_line[location_or + 3:-1].split(',')
          circuit_gate.append(gate_output)
          node_type[gate_output] = 'OR'
          
          inputs_clean = []
          for input_node in inputs:
            cleaned = input_node.strip()
            inputs_clean.append(cleaned)
    
          circuit_line.append(
            f'{gate_output} = OR{inputs_clean}'
            )
    
          if gate_output not in node_prerequiste:
            node_prerequiste[gate_output] = []
            node_dependents[gate_output] = []
    
          for node in inputs_clean:
    
            if node not in node_prerequiste[gate_output]:
              node_prerequiste[gate_output].append(node)
    
            if node not in node_prerequiste:
              node_prerequiste[node] = []
              node_dependents[node] = []
    
            if gate_output not in node_dependents[node]:
              node_dependents[node].append(gate_output)
    
        ####################################################################
    
        # NOR GATE FORMATTING
      if location_nor != -1:
    
          gate_output = formatted_line[:location_equal].strip()
          gate_output = gate_output.strip('=')
          inputs = formatted_line[location_nor + 4:-1].split(',')
          circuit_gate.append(gate_output)
          node_type[gate_output] = 'NOR'
          
          inputs_clean = []
          for input_node in inputs:
            cleaned = input_node.strip()
            inputs_clean.append(cleaned)
    
          circuit_line.append(
            f'{gate_output} = NOR{inputs_clean}'
          )
    
          if gate_output not in node_prerequiste:
            node_prerequiste[gate_output] = []
            node_dependents[gate_output] = []
    
          for node in inputs_clean:
    
            if node not in node_prerequiste[gate_output]:
              node_prerequiste[gate_output].append(node)
    
            if node not in node_prerequiste:
              node_prerequiste[node] = []
              node_dependents[node] = []
    
            if gate_output not in node_dependents[node]:
              node_dependents[node].append(gate_output)
    
        ####################################################################
    
        # XOR GATE FORMATTING
      if location_xor != -1:
    
          gate_output = formatted_line[:location_equal].strip()
          gate_output = gate_output.strip('=')
          inputs = formatted_line[location_xor + 4:-1].split(',')
          circuit_gate.append(gate_output)
          node_type[gate_output] = 'XOR'
          
          inputs_clean = []
          for input_node in inputs:
            cleaned = input_node.strip()
            inputs_clean.append(cleaned)
    
          circuit_line.append(
            f'{gate_output} = XOR{inputs_clean}'
          )
    
          if gate_output not in node_prerequiste:
            node_prerequiste[gate_output] = []
            node_dependents[gate_output] = []
    
          for node in inputs_clean:
    
            if node not in node_prerequiste[gate_output]:
              node_prerequiste[gate_output].append(node)
    
            if node not in node_prerequiste:
              node_prerequiste[node] = []
              node_dependents[node] = []
    
            if gate_output not in node_dependents[node]:
              node_dependents[node].append(gate_output)
    
      ####################################################################
    
      # NOT GATE FORMATTING
      if location_not != -1:
    
          gate_output = formatted_line[:location_equal].strip()
          gate_output = gate_output.strip('=')
          #gate_output = gate_output.replace("'", r"\'")
          ##print(gate_output)
          input_node = formatted_line[location_not + 4:-1].strip()
          circuit_gate.append(gate_output)
          node_type[gate_output] = 'NOT'
          
          circuit_line.append(
            f'{gate_output} = NOT[{input_node}]'
          )
    
          if gate_output not in node_prerequiste:
            node_prerequiste[gate_output] = []
            node_dependents[gate_output] = []
    
          if input_node not in node_prerequiste:
            node_prerequiste[input_node] = []
            node_dependents[input_node] = []
    
          if gate_output not in node_dependents[input_node]:
            node_dependents[input_node].append(gate_output)
    
          node_prerequiste[gate_output].append(input_node)
    
    ####################################################################
    
    # BUFF GATE FORMATTING
      if location_buff != -1:
    
          gate_output = formatted_line[:location_equal].strip()
          gate_output = gate_output.strip('=')
          input_node = formatted_line[location_buff + 5:-1].strip(',')
          circuit_gate.append(gate_output)
          node_type[gate_output] = 'BUFF'
          
          circuit_line.append(
            f'{gate_output} = BUFF[{input_node}]'
          )
    
          if gate_output not in node_prerequiste:
            node_prerequiste[gate_output] = []
            node_dependents[gate_output] = []
    
          if input_node not in node_prerequiste:
            node_prerequiste[input_node] = []
            node_dependents[input_node] = []
    
          if gate_output not in node_dependents[input_node]:
            node_dependents[input_node].append(gate_output)
    
          node_prerequiste[gate_output].append(input_node)
    
    ####################################################################
    # $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
    ####################################################################
    # $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
    ####################################################################
    # $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
    ####################################################################
    # $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
    ####################################################################
    # $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
    ####################################################################

  print('') 
  print('(Controlability Calculation) = 1')
  print('(Monte Carlos Simulation) = 2')
  print('')

  choice = input('Choose (1 or 2): ')

  if (int(choice) == 1):
    
    
    for node in circuit_inputs:
      node_control[node] = [1,1]
      
    zero_val = 0
    one_val = 0

    for node in circuit_gate:

      ####################################################################
      # AND Gate
      ####################################################################

      if node_type[node] == 'AND':
        
        # C0 (min)
        zero_val = node_control[node_prerequiste[node][0]][0]
        
        # C1 (max)
        one_val = 0
        
        for val in node_prerequiste[node]:
          c0 = node_control[val][0]
          c1 = node_control[val][1]
          
          # max
          one_val += c1
          
          # min
          if c0 < zero_val:
            zero_val = c0
        
        one_val += 1
        zero_val += 1
        
        node_control[node] = [zero_val, one_val]
        
        zero_val = 0
        one_val = 0
      
      ####################################################################
      # NAND Gate
      ####################################################################

      elif node_type[node] == 'NAND':
        
        # C0 (max)
        zero_val = 0
        
        # C1 (min)
        one_val = node_control[node_prerequiste[node][0]][0]
        
        for val in node_prerequiste[node]:
          c0 = node_control[val][0]
          c1 = node_control[val][1]
          
          # max
          zero_val += c1
          
          # min
          if c0 < one_val:
            one_val = c0
        
        one_val += 1
        zero_val += 1
        
        node_control[node] = [zero_val, one_val]
        
        zero_val = 0
        one_val = 0   

      ####################################################################
      # OR Gate
      ####################################################################

      elif node_type[node] == 'OR':
        
        # C0 (max)
        zero_val = 0
        
        # C1 (min)
        one_val = node_control[node_prerequiste[node][0]][1]
        
        for val in node_prerequiste[node]:
          c0 = node_control[val][0]
          c1 = node_control[val][1]
          
          # max
          zero_val += c0
          
          # min
          if c1 < one_val:
            one_val = c1
        
        one_val += 1
        zero_val += 1
        
        node_control[node] = [zero_val, one_val]
        
        zero_val = 0
        one_val = 0 

      ####################################################################
      # NOR Gate
      ####################################################################

      elif node_type[node] == 'NOR':
        
        # C1 (max)
        one_val = 0
        
        # C0 (min)
        zero_val = node_control[node_prerequiste[node][0]][1]
        
        for val in node_prerequiste[node]:
          c0 = node_control[val][0]
          c1 = node_control[val][1]
          
          # max
          one_val += c0
          
          # min
          if c1 < zero_val:
            zero_val = c1
        
        one_val += 1
        zero_val += 1
        
        node_control[node] = [zero_val, one_val]
        
        zero_val = 0
        one_val = 0 
      ####################################################################
      # XOR Gate
      ####################################################################

      elif node_type[node] == 'XOR':
        
        # C1 (max)
        one_val = 0
        
        # C0 (min)
        zero_val = 0
        
        c0_a = node_control[node_prerequiste[node][0]][0]
        c1_a = node_control[node_prerequiste[node][0]][1]
        c0_b = node_control[node_prerequiste[node][1]][0]
        c1_b = node_control[node_prerequiste[node][1]][1]
        
        sum_00 = c0_a + c0_b
        sum_11 = c1_a + c1_b
        
        min_yo = sum_00
        
        if(sum_11 < min_yo):
          min_yo = sum_11
        
        sum_01 = c0_a + c1_b
        sum_10 = c1_a + c0_b
        
        min_yo2 = sum_01
        
        if(sum_10 < min_yo2):
          min_yo = sum_10
        
        zero_val = min_yo + 1
        one_val = min_yo2 + 1
        
        node_control[node] = [zero_val, one_val]
        
        zero_val = 0
        one_val = 0
        
      ####################################################################
      # NOT Gate
      ####################################################################

      elif node_type[node] == 'NOT':
        
        c0 = node_control[node_prerequiste[node][0]][0]
        c1 = node_control[node_prerequiste[node][0]][1]
        
        node_control[node] = [c1 + 1, c0 + 1]
        
      ####################################################################
      # BUFF (Buffer) Gate
      ####################################################################

      elif node_type[node] == 'BUFF':
        
        c0 = node_control[node_prerequiste[node][0]][0]
        c1 = node_control[node_prerequiste[node][0]][1]
        
        node_control[node] = [c0 + 1, c1 + 1]

      ####################################################################
    print('')
    print('######################################')
    print('')
    print('Results of Controlability Calculation')
    print('')
    print('EXAMPLE')
    print('node: (c0, c1)')
    print('')
    
    for node, vals in node_control.items():
      print(f'{node}: ({vals[0]}, {vals[1]})')
      
    
    print('')
    print('######################################')
    
  if (int(choice) == 2):
    #print('yo')
    #def evaluate_circuit(inputs, circuit_gates, node_prerequiste):
    circuit_inputs_eval = {}
    node_mc_count = {}
    
    for node in circuit_inputs:
      node_mc_count[node] = [0, 0]
      
    for node in circuit_outputs:
      node_mc_count[node] = [0, 0]
    
    for node in circuit_gate:
      node_mc_count[node] = [0, 0]
    
    for i in range(1000):

      for node in circuit_inputs:
        circuit_inputs_eval[node] = random.randint(0,1)
      
      #print(circuit_inputs_eval)
        
      output_values = evaluate_circuit(circuit_inputs_eval, circuit_line, node_prerequiste)
      
      for node, val in output_values.items():
        #print(f'{node}: {val}')
        if (val == 0):
          node_mc_count[node][0] += 1
        elif (val == 1):
          node_mc_count[node][1] += 1
    print('')
    print('######################################')
    print('')
    print('Results of Monte Carlos Simulation')
    print('')
    
    print('Choices for MC Simulation Results')
    print('Formatted List = 1')
    print('Normal List = 2')
    choice_gh = input('Enter Choice: ')
    
    if(int(choice_gh) == 1):
    
      print('EXAMPLE')
      print('node')
      print(f"{'n0':<6}| {'n1':<6}")
      print(f"{'n0 val':<6}| {'n1 val':<6}")
      print('')
      
      for node, val in node_mc_count.items():
        print(f"{node}")
        print(f"{'n0':<6}| {'n1':<6}")
        print(f"{val[0]:<6}| {val[1]:<6}\n")
      
    elif(int(choice_gh) == 2):
      
      print('')
      for node, val in node_mc_count.items():
        print(f'{node}: {val}')


    print('')
    print('######################################')
